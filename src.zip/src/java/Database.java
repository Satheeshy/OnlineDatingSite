
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author yadavas9800
 */
public class Database {
    
    public static Connection getconnect(){
        Connection con = null;
        try{
            Class.forName("com.mysql.jdbc.Driver");
          con = DriverManager.getConnection("jdbc:mysql://mis-sql.uhcl.edu/kurapativ5434", "kurapativ5434", "1447544");
            
        }
        catch(Exception e){
            e.printStackTrace();;
        }
        return con;
    }
    
     public static User UserData(String username)
    {
        Connection conn =null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        User udata = null;
        try
        {
            conn = getconnect();
           //first assign user profile
           udata = getUserProfileOfUser(username);
           //now assign friendlist
           udata.setFriends(getFriendList(username));
           //now get messages
           udata.setChats(getMessages(username));
           //now get search except quick search
           Match obj = new Match(getMyInterestMatchingFriends(username), getMatchByPreferences(username), getFriendViewedMyProfile(username));
           udata.setMatch_serches(obj);
           //now check to whom he sent request and from whom he received request
           
           udata.setViewSentFriendRequest(viewSentFriendRequest(username));
           udata.setViewreceivedFriendRequest(viewReceivedFriendRequest(username));
            
            
        }
        catch(Exception e){
            e.printStackTrace();
        }
            
      
        
        return udata;
        
    }
    
    public static User getUserProfileOfUser(String username){
        
        Connection conn =null;
        Statement stat = null;
        ResultSet rs = null;
        User udata = null;
        try{
            conn = getconnect();
             stat = conn.createStatement();
            rs = stat.executeQuery("select * from datingtest01 where userid = '"+username+"'");
          
            while(rs.next())
            {
               udata = new User(rs.getString(1),rs.getString(2),rs.getString(3),
                                   rs.getString(4),rs.getString(5),rs.getString(6),
                                   rs.getInt(7),rs.getString(8),rs.getString(9),
                                   rs.getString(10),rs.getString(11),rs.getString(12),
                                   rs.getString(13),rs.getString(14),rs.getString(15),
                                   rs.getString(16),rs.getString(17),rs.getDouble(18),
                                   rs.getString(19),rs.getString(20),rs.getString(21),
                                   rs.getString(22),rs.getString(23),rs.getString(24),
                                   rs.getString(25),rs.getString(26),rs.getInt(27),
                                   rs.getString(28),rs.getDouble(29),rs.getString(30),
                                   rs.getString(31),rs.getString(32),rs.getString(33),
                                   rs.getString(34),rs.getString(35));
            }
            
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return udata;
    }
    
    public static ArrayList<FriendList> getFriendList(String usernmae){
        Connection conn =null;
        PreparedStatement ps =null;
        ResultSet rs = null;
        ArrayList<FriendList> friends = new ArrayList<>();
        try
        {
            conn = getconnect();
            ps = conn.prepareStatement("SELECT * FROM friendrelation where userid = ?");
            ps.setString(1, usernmae);
            rs = ps.executeQuery();
            
            while(rs.next()){
                User u = getUserProfileOfUser(rs.getString(1));
                FriendList f = new FriendList();
                f.setFriend(u);
                friends.add(f);
            }
          
            
            
        }
        catch(Exception e){
            e.printStackTrace();
        }
            
      
        return friends;
       
    }
    
    public static void createAccount(User u){
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try{
            con = getconnect();
            ps = con.prepareStatement("insert into datingtest01 values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            ps.setString(1,u.getUfirstname());
            ps.setString(2,u.getUlastname());
            ps.setString(3,u.getUserid());
            ps.setString(4,u.getUemailid());
            ps.setString(5,u.getUpassword());
            ps.setString(6,u.getUgender());
            ps.setInt(7,u.getUage());
            ps.setString(8,u.getUcity());
            ps.setString(9,u.getUzipcode());
            ps.setString(10,u.getUdob());
            ps.setString(11,u.getUethnicity());
            ps.setString(12,u.getUreligion());
            ps.setString(13,u.getUlanguage());
            ps.setString(14,u.getUseeking());
            ps.setString(15,u.getUrelationshipstatus());
            ps.setString(16,u.getUeducation());
            ps.setString(17,u.getUoccupation());
            ps.setDouble(18,u.getUincome());
            ps.setString(19,u.getUtype());
            ps.setString(20,u.getUinterest01());
            ps.setString(21,u.getUinterest02());
            ps.setString(22,u.getUinterest03());
            ps.setString(23,u.getUsecurityq01());
            ps.setString(24,u.getUsecurityq02());
            ps.setString(25,u.getUanswer01());
            ps.setString(26,u.getUanswer02());
            ps.setInt(27,u.getMage());
            ps.setString(28,u.getMlanguage());
            ps.setDouble(29,u.getMincome());
            ps.setString(30,u.getMrelationshipstatus());
            ps.setString(31,u.getMreligion());
            ps.setString(32,u.getMethnicity());
            ps.setString(33,u.getMeducation());
            ps.setString(34,u.getMoccupation());
            ps.setString(35,u.getMcity());
            ps.executeUpdate();
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }

    public static ArrayList<chatBox> getMessages(String username){
          Connection conn =null;
        PreparedStatement ps = null;
        ResultSet rs = null;
          ArrayList<chatBox> getMessages = new ArrayList<>();
        try
        {
             }
        catch(Exception e){
            e.printStackTrace();
        }
            
      
        return getMessages;
    }
    
    public static String checkUser(String username,String password){
          Connection con = null;
        try {
            con = Database.getconnect();
            PreparedStatement ps = con.prepareStatement("select * from datingtest01 where userid=?");
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                if (rs.getString(3).equals(username)) {
                    if (rs.getString(5).equals(password)) {
                        return "successful";
                    }
                    return "not successful";
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "not successful";
    }
    
    public static ArrayList<FriendList> getMatchByPreferences(String username){
         Connection con = null;
          Statement stat=null;
          ResultSet rs=null;
          
        ArrayList<FriendList> friends = new ArrayList<>();
        
        try {
            con = Database.getconnect();
            stat =con.createStatement();
            String mlanguage="";
            String methnicity="";
            int mage=0;
            double mincome=0;
            String mrelationshipstatus="";
            String moccupation="";
            String meducation="";
            String mcity="";
            rs=stat.executeQuery("select *from datingtest01 where userid='"+username+"'");
            
            while(rs.next())
            {
                mlanguage=rs.getString("mlanguage");
                methnicity= rs.getString("methnicity");
                mage=rs.getInt("mage");
                mincome=rs.getDouble("mincome");
                mrelationshipstatus=rs.getString("mrelationshipstatus");
                moccupation=rs.getString("moccupation");
                meducation=rs.getString("meducation");
                mcity=rs.getString("mcity");
                
              
            }
            rs=null;
           
            //get data about who are already matched, friends
            rs=stat.executeQuery("select muserid from matched where userid='+"+username+"'");
            ArrayList<String> matched= new ArrayList<String>();
            while(rs.next())
            {
                matched.add(rs.getString("muserid"));
            }
            rs=null;
            rs=stat.executeQuery("select userid from datingtest01 where mlanguage='"+mlanguage+"' or methniciyt='"+methnicity+"' or "
                    + "mage="+mage+" or mincome="+mincome+" or mrelationshipstatus='"+mrelationshipstatus+"' or moccupation='"+moccupation+"' "
                    + "or meducation='"+meducation+"' or mcity="+mcity+"'");
            while(rs.next())
            {
                if(!matched.contains(rs.getString("userid")))
                {
                     FriendList f = new FriendList();
                     f.setFriend(getUserProfileOfUser(rs.getString("userid")));
                     friends.add(f);
                }
               
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        return friends;
        
    }
    
    public static ArrayList<FriendList> getMyInterestMatchingFriends(String username){
      Connection con = null;
          Statement stat=null;
          ResultSet rs=null;
          
        ArrayList<FriendList> friends = new ArrayList<>();
        
        try {
            con = Database.getconnect();
            stat =con.createStatement();
            String mlanguage="";
            String methnicity="";
            int mage=0;
            double mincome=0;
            String mrelationshipstatus="";
            String moccupation="";
            String meducation="";
            String mcity="";
            rs=stat.executeQuery("select * from datingtest01 where userid='"+username+"'");
            
            while(rs.next())
            {
                 mlanguage=rs.getString("ulanguage");
                methnicity= rs.getString("uethnicity");
                mage=rs.getInt("uage");
                mincome=rs.getDouble("uincome");
                mrelationshipstatus=rs.getString("urelationshipstatus");
                moccupation=rs.getString("uoccupation");
                meducation=rs.getString("ueducation");
                mcity=rs.getString("ucity");   
                }
            rs=null;
           
            //get data about who are already matched, friends
            rs=stat.executeQuery("select muserid from matched where userid='+"+username+"'");
            ArrayList<String> matched= new ArrayList<String>();
            while(rs.next())
            {
                matched.add(rs.getString("muserid"));
            }
            rs=null;
            rs=stat.executeQuery("select userid from datingtest01 where mlanguage='"+mlanguage+"' or methniciyt='"+methnicity+"' or "
                    + "mage="+mage+" or mincome="+mincome+" or mrelationshipstatus='"+mrelationshipstatus+"' or moccupation='"+moccupation+"' "
                    + "or meducation='"+meducation+"' or mcity="+mcity+"'");
            while(rs.next())
            {
                if(!matched.contains(rs.getString("userid")))
                {
                     FriendList f = new FriendList();
                     f.setFriend(getUserProfileOfUser(rs.getString("userid")));
                     friends.add(f);
                }
               
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        return friends;
    }
    
    public static ArrayList<FriendList> getFriendViewedMyProfile(String username){
         Connection conn =null;
        PreparedStatement ps = null;
        ResultSet rs = null;
          ArrayList<FriendList> friends = new ArrayList<>();
        try
        {
            conn = getconnect();
           
            ps = conn.prepareStatement("select * from viewed where userid = ?");
            ps.setString(1, username);
            rs = ps.executeQuery();
            
            while(rs.next()){
                FriendList f = new FriendList();
                f.setFriend(getUserProfileOfUser(rs.getString(2)));
                friends.add(f);
            }
            
            
        }
        catch(Exception e){
            e.printStackTrace();
        }
            
      
        return friends;
      
    }
    
    public static ArrayList<FriendList> getByLocationAge(String username){
          Connection conn =null;
        PreparedStatement ps = null;
        ResultSet rs = null;
          ArrayList<FriendList> friends = new ArrayList<>();
        try
        {
             }
        catch(Exception e){
            e.printStackTrace();
        }
            
      
        return friends;
        
    }
  
    
   public static void sendFriendRequest(String user_id,String friend_id) {
        Connection con = null;
        try {
            con = Database.getconnect();
            //before adding check both uses

            PreparedStatement ps = con.prepareStatement("insert into relationstatus values(?,?,?)");
            ps.setString(1, user_id);
            ps.setString(2, friend_id);
            ps.setString(3, "pending");
            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static ArrayList<FriendList> viewSentFriendRequest(String user_id) {
        Connection con = null;
        ResultSet rs = null;
        ArrayList<FriendList> viewSentFriendRequest = new ArrayList<>();
        try {
             con = Database.getconnect();
            //before adding check both uses

            PreparedStatement ps = con.prepareStatement("select * from relationstatus where senderid=? and accepted=? ");
            ps.setString(1, user_id);
            ps.setString(2, "pending");
            rs = ps.executeQuery();
            while (rs.next()) {
               FriendList f = new FriendList();
               f.setFriend(getUserProfileOfUser(rs.getString(2)));
                viewSentFriendRequest.add(f);

            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return viewSentFriendRequest;
    }

    public static void cancelFriendRequest(String user_id, String friend_id) {
        Connection con = null;
        try {
             con = Database.getconnect();
            //before adding check both uses

            PreparedStatement ps = con.prepareStatement("delete relationstatus where senderid=? and receiverid=?");
            ps.setString(1, user_id);
            ps.setString(2, friend_id);
            ps.executeUpdate();
            ps = con.prepareStatement("delete relationstatus where sender=? and receiverid=?");
            ps.setString(2, user_id);
            ps.setString(1, friend_id);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static ArrayList<FriendList> viewReceivedFriendRequest(String user_id) {
        Connection con = null;
        ResultSet rs = null;
        ArrayList<FriendList> viewReceivedFriendRequest = new ArrayList<>();
        try {
             con = Database.getconnect();
            //before adding check both uses

            PreparedStatement ps = con.prepareStatement("select * from relationstatus where receiverid=? and accepted=?");
            ps.setString(1, user_id);
            ps.setString(2, "pending");
            rs = ps.executeQuery();
            while (rs.next()) { 
                FriendList f = new FriendList();
               f.setFriend(getUserProfileOfUser(rs.getString(2)));
                viewReceivedFriendRequest.add(f);

            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return viewReceivedFriendRequest;
    }

    public static void acceptFriendReqest(String user_id, String friend_id) {
        Connection con = null;
        try {
            con = Database.getconnect();
            //before adding check both uses

          
            PreparedStatement ps = con.prepareStatement("insert into friendrelation values(?,?)");
            ps.setString(1, user_id);
            ps.setString(2, friend_id);
            ps.executeUpdate();
            //insert another recoerd
             ps = con.prepareStatement("insert into friendrelation values(?,?)");
            ps.setString(1, friend_id);
            ps.setString(2, user_id);
            ps.executeUpdate();
              ps = con.prepareStatement("delete from realtionstatus where (senderid =? and receiverid=?) or (senderid =? and receiverid=?)");
            ps.setString(1, friend_id);
            ps.setString(2, user_id);
            ps.setString(3, user_id);
            ps.setString(4, friend_id);
            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
