/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;

/**
 *
 * @author yadavas9800
 */
@Named(value = "login")
@SessionScoped
public class login implements Serializable {

    /**
     * Creates a new instance of login
     */
    public login() {
    }
    
     
    private String username;
    private String password;
    private User loginId;
    private User friend_id;
    
    public String checkUser(){
        String a = Database.checkUser("test1", "test1");
        //obj = db.getuser(username);
       
        if(a.equals("successful")){
            this.loginId = new User(username);
            return "welcome";
        }
        else{
            return "loginagain";
        }
    }
      
      public void addFriend(){
          
      }
      
      
    

    public String getPassword() {
        return password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public User getLoginId() {
        return loginId;
    }

    public void setLoginId(User loginId) {
        this.loginId = loginId;
    }
    
    
    
}
